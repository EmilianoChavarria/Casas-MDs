/**
 * Todos los montos están en la moneda base (USD) y ya vienen calculados.
 * El frontend nunca calcula precios: solo muestra estos números.
 */

export interface NightLine {
  date: string; // ISO
  price: number;
  season: string | null;
}

export interface FeeLine {
  id: string;
  labelKey: string;
  amount: number;
  calc: 'fixedPerStay' | 'fixedPerNight' | 'percentage';
  detail?: string;
}

export interface TaxLine {
  id: string;
  labelKey: string;
  amount: number;
  /** 'percentage' muestra la tasa; 'fixedPerNight' deja claro que NO es porcentaje. */
  calc: 'percentage' | 'fixedPerNight';
  rate: number;
}

export interface DiscountLine {
  id: string;
  label: string;
  amount: number; // negativo
}

export interface Breakdown {
  nights: NightLine[];
  subtotal: number;
  discounts: DiscountLine[];
  fees: FeeLine[];
  taxes: TaxLine[];
  total: number;
}

const iso = (d: string) => d;

/** Desglose de ejemplo: 5 noches en diciembre, cruzando dos temporadas. */
export const SAMPLE_BREAKDOWN: Breakdown = {
  nights: [
  { date: iso('2026-12-16'), price: 240, season: 'Puente de diciembre' },
  { date: iso('2026-12-17'), price: 240, season: 'Puente de diciembre' },
  { date: iso('2026-12-18'), price: 330, season: 'Navidad' },
  { date: iso('2026-12-19'), price: 390, season: 'Navidad' },
  { date: iso('2026-12-20'), price: 390, season: 'Navidad' }],

  subtotal: 1590,
  discounts: [{ id: 'd1', label: 'INVIERNO26 · 15%', amount: -238 }],
  fees: [
  { id: 'f1', labelKey: 'fees.cleaning', amount: 85, calc: 'fixedPerStay' },
  { id: 'f2', labelKey: 'fees.extraGuest', amount: 60, calc: 'fixedPerNight', detail: '2 × 5' }],

  taxes: [
  { id: 't1', labelKey: 'fees.iva', amount: 238.5, calc: 'percentage', rate: 16 },
  { id: 't2', labelKey: 'fees.ish', amount: 47.7, calc: 'percentage', rate: 3 },
  { id: 't3', labelKey: 'fees.dsa', amount: 12.5, calc: 'fixedPerNight', rate: 2.5 }],

  total: 1795.2
};

export interface FeeConfig {
  id: string;
  labelKey: string;
  calc: 'percentage' | 'fixedPerNight' | 'fixedPerStay';
  value: number;
  enabled: boolean;
}

export const FEE_CONFIG: FeeConfig[] = [
{ id: 'cleaning', labelKey: 'fees.cleaning', calc: 'fixedPerStay', value: 85, enabled: true },
{ id: 'extraGuest', labelKey: 'fees.extraGuest', calc: 'fixedPerNight', value: 15, enabled: true },
{ id: 'pet', labelKey: 'fees.pet', calc: 'fixedPerStay', value: 20, enabled: false }];


export interface TaxConfig {
  id: string;
  labelKey: string;
  calc: 'percentage' | 'fixedPerNight';
  value: number;
  enabled: boolean;
}

export const TAX_CONFIG: TaxConfig[] = [
{ id: 'iva', labelKey: 'fees.iva', calc: 'percentage', value: 16, enabled: true },
{ id: 'ish', labelKey: 'fees.ish', calc: 'percentage', value: 3, enabled: true },
{ id: 'dsa', labelKey: 'fees.dsa', calc: 'fixedPerNight', value: 2.5, enabled: true }];


/** Simulación de 12 meses: promedio por noche antes y después de las reglas. */
export interface PreviewMonth {
  month: number; // 0-11
  year: number;
  before: number;
  after: number;
  season: string | null;
}

export const PREVIEW_MONTHS: PreviewMonth[] = [
{ month: 8, year: 2026, before: 180, after: 144, season: 'Temporada baja lluvias' },
{ month: 9, year: 2026, before: 180, after: 144, season: 'Temporada baja lluvias' },
{ month: 10, year: 2026, before: 180, after: 189, season: null },
{ month: 11, year: 2026, before: 180, after: 268, season: 'Navidad' },
{ month: 0, year: 2027, before: 180, after: 246, season: 'Temporada alta invierno' },
{ month: 1, year: 2027, before: 180, after: 225, season: 'Temporada alta invierno' },
{ month: 2, year: 2027, before: 180, after: 238, season: 'Temporada alta invierno' },
{ month: 3, year: 2027, before: 180, after: 252, season: 'Semana Santa' },
{ month: 4, year: 2027, before: 180, after: 189, season: null },
{ month: 5, year: 2027, before: 180, after: 189, season: null },
{ month: 6, year: 2027, before: 180, after: 198, season: null },
{ month: 7, year: 2027, before: 180, after: 198, season: null }];


/** Precios por noche para el calendario del huésped, generados sobre la marcha. */
export function nightlyPriceMap(base: number, months = 3): Record<string, number> {
  const map: Record<string, number> = {};
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  for (let i = 0; i < months * 31; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    const day = d.getDay();
    const isWeekend = day === 5 || day === 6;
    const isDecember = d.getMonth() === 11 && d.getDate() >= 18;
    let price = base;
    if (isWeekend) price = Math.round(price * 1.18);
    if (isDecember) price = Math.round(price * 1.65);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    map[`${y}-${m}-${dd}`] = price;
  }
  return map;
}
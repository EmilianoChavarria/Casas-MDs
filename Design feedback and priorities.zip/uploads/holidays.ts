export interface Holiday {
  id: string;
  name: string;
  date: string; // ISO
}

export const HOLIDAYS: Holiday[] = [
{ id: 'h1', name: 'Año Nuevo', date: '2027-01-01' },
{ id: 'h2', name: 'Día de la Constitución', date: '2027-02-01' },
{ id: 'h3', name: 'Natalicio de Benito Juárez', date: '2027-03-15' },
{ id: 'h4', name: 'Jueves Santo', date: '2027-03-25' },
{ id: 'h5', name: 'Viernes Santo', date: '2027-03-26' },
{ id: 'h6', name: 'Día del Trabajo', date: '2027-05-01' },
{ id: 'h7', name: 'Independencia de México', date: '2027-09-16' },
{ id: 'h8', name: 'Día de Muertos', date: '2027-11-02' },
{ id: 'h9', name: 'Revolución Mexicana', date: '2027-11-15' },
{ id: 'h10', name: 'Navidad', date: '2027-12-25' },
{ id: 'h11', name: 'Año Nuevo', date: '2026-01-01' },
{ id: 'h12', name: 'Independencia de México', date: '2026-09-16' },
{ id: 'h13', name: 'Día de Muertos', date: '2026-11-02' },
{ id: 'h14', name: 'Navidad', date: '2026-12-25' }];


export type DayType = 'weekday' | 'weekend' | 'holiday';

export interface DayRule {
  type: DayType;
  adjustType: 'percentage' | 'fixed';
  value: number;
}

export const DAY_RULES: DayRule[] = [
{ type: 'weekday', adjustType: 'percentage', value: 0 },
{ type: 'weekend', adjustType: 'percentage', value: 18 },
{ type: 'holiday', adjustType: 'percentage', value: 35 }];


/**
 * Qué días cuentan como fin de semana. 0 = domingo … 6 = sábado.
 * En el Caribe mexicano el fin de semana comercial es viernes y sábado.
 */
export const DEFAULT_WEEKEND_DAYS = [5, 6];

export const WEEKDAY_NAMES = [
'Domingo',
'Lunes',
'Martes',
'Miércoles',
'Jueves',
'Viernes',
'Sábado'];
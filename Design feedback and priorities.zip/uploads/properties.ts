import { Property, Zone } from './types';
import { addDays, toISODate } from '../lib/format';

const IMG = {
  beachfront: "/aa01a86b-e731-4b35-8848-5dbc3498b75c.jpg",
  pool: "/9034e20a-2626-4013-b5d8-301821546494.jpg",
  interior: "/e09dc53a-971e-4cab-9715-82b3d2c24dfa.jpg",
  hero: "/524bf99d-942e-4639-9d85-deeeff1758d1.jpg",
  isla: "/2f4b5e8c-6192-421f-8b76-7d990062a060.jpg"
};

export const HERO_IMAGE = IMG.hero;

export const ZONES: Zone[] = [
{ id: 'playa-del-carmen', name: 'Playa del Carmen', image: IMG.pool, count: 3 },
{ id: 'isla-mujeres', name: 'Isla Mujeres', image: IMG.isla, count: 2 },
{ id: 'tulum', name: 'Tulum', image: IMG.beachfront, count: 1 },
{ id: 'cancun', name: 'Cancún', image: IMG.interior, count: 1 }];


export function zoneName(id: string): string {
  return ZONES.find((z) => z.id === id)?.name ?? id;
}

// Generate some booked/blocked dates relative to today so the calendar looks alive.
function futureDates(startOffset: number, len: number): string[] {
  const today = new Date();
  const out: string[] = [];
  for (let i = 0; i < len; i++) {
    out.push(toISODate(addDays(today, startOffset + i)));
  }
  return out;
}

const sampleReviews = (base: string) => [
{
  id: base + '-r1',
  author: 'Emily Carter',
  country: '🇺🇸 USA',
  avatar: 'https://i.pravatar.cc/120?img=47',
  rating: 5,
  date: '2026-05-12',
  textES: 'Increíble estancia, la casa es aún más bonita que en las fotos. El anfitrión responde súper rápido.',
  textEN: 'Amazing stay, the house is even nicer than in the photos. The host replies super fast.',
  textFR: 'Séjour incroyable, la maison est encore plus belle que sur les photos. Hôte très réactif.'
},
{
  id: base + '-r2',
  author: 'Antoine Dubois',
  country: '🇫🇷 France',
  avatar: 'https://i.pravatar.cc/120?img=12',
  rating: 5,
  date: '2026-04-03',
  textES: 'Ubicación perfecta, a pasos de la playa. Volveremos sin duda.',
  textEN: 'Perfect location, steps from the beach. We will definitely be back.',
  textFR: "Emplacement parfait, à deux pas de la plage. Nous reviendrons sans hésiter."
},
{
  id: base + '-r3',
  author: 'María González',
  country: '🇲🇽 México',
  avatar: 'https://i.pravatar.cc/120?img=32',
  rating: 4,
  date: '2026-03-18',
  textES: 'Muy limpia y cómoda. La alberca es un lujo. Recomendada al 100%.',
  textEN: 'Very clean and comfortable. The pool is a treat. 100% recommended.',
  textFR: 'Très propre et confortable. La piscine est un vrai plus. Je recommande à 100 %.'
}];


export const PROPERTIES: Property[] = [
{
  id: 'p1',
  slug: 'villa-turquesa',
  name: 'Villa Turquesa Beachfront',
  type: 'villa',
  zone: 'playa-del-carmen',
  location: 'Playacar, Playa del Carmen',
  lat: 20.615,
  lng: -87.081,
  pricePerNight: 420,
  cleaningFee: 90,
  rating: 4.96,
  reviewCount: 128,
  guests: 8,
  bedrooms: 4,
  beds: 5,
  baths: 4,
  images: [IMG.beachfront, IMG.pool, IMG.interior, IMG.isla],
  amenities: ['wifi', 'pool', 'beachfront', 'ac', 'kitchen', 'parking', 'ocean-view', 'bbq', 'tv', 'washer'],
  featured: true,
  active: true,
  descES:
  'Villa de lujo justo frente al mar con alberca infinita y acceso directo a la playa. Amplios espacios abiertos, terrazas con vista al Caribe y una cocina totalmente equipada. Ideal para familias o grupos que buscan la escapada perfecta.',
  descEN:
  'Luxury beachfront villa with an infinity pool and direct beach access. Spacious open-plan living, terraces overlooking the Caribbean and a fully equipped kitchen. Perfect for families or groups seeking the ultimate getaway.',
  descFR:
  "Villa de luxe en bord de mer avec piscine à débordement et accès direct à la plage. Grands espaces ouverts, terrasses avec vue sur les Caraïbes et cuisine entièrement équipée. Idéale pour les familles ou groupes.",
  rulesES: ['Check-in después de las 15:00', 'Check-out antes de las 11:00', 'No fiestas ni eventos', 'No fumar en interiores'],
  rulesEN: ['Check-in after 3:00 PM', 'Check-out before 11:00 AM', 'No parties or events', 'No smoking indoors'],
  rulesFR: ["Arrivée après 15h00", 'Départ avant 11h00', 'Pas de fêtes ni événements', 'Non-fumeur à l\'intérieur'],
  reviews: sampleReviews('p1'),
  bookedDates: futureDates(4, 5),
  blockedDates: futureDates(20, 2)
},
{
  id: 'p2',
  slug: 'casa-coral',
  name: 'Casa Coral con Alberca',
  type: 'house',
  zone: 'playa-del-carmen',
  location: 'Centro, Playa del Carmen',
  lat: 20.629,
  lng: -87.073,
  pricePerNight: 260,
  cleaningFee: 60,
  rating: 4.88,
  reviewCount: 94,
  guests: 6,
  bedrooms: 3,
  beds: 3,
  baths: 2,
  images: [IMG.pool, IMG.interior, IMG.beachfront],
  amenities: ['wifi', 'pool', 'ac', 'kitchen', 'parking', 'washer', 'tv', 'workspace'],
  featured: true,
  active: true,
  descES:
  'Casa moderna a solo dos cuadras de la 5ta Avenida, con alberca privada y jardín tropical. Perfecta para quienes quieren estar cerca de la vida nocturna y las tiendas de Playa del Carmen.',
  descEN:
  'Modern house just two blocks from 5th Avenue, with a private pool and tropical garden. Perfect for those who want to be close to Playa del Carmen’s nightlife and shops.',
  descFR:
  "Maison moderne à deux rues de la 5e Avenue, avec piscine privée et jardin tropical. Parfaite pour être proche de la vie nocturne et des boutiques de Playa del Carmen.",
  rulesES: ['Check-in después de las 16:00', 'Check-out antes de las 11:00', 'Se permiten mascotas pequeñas'],
  rulesEN: ['Check-in after 4:00 PM', 'Check-out before 11:00 AM', 'Small pets allowed'],
  rulesFR: ['Arrivée après 16h00', 'Départ avant 11h00', 'Petits animaux acceptés'],
  reviews: sampleReviews('p2'),
  bookedDates: futureDates(10, 4),
  blockedDates: []
},
{
  id: 'p3',
  slug: 'bungalow-arena',
  name: 'Bungalow Arena Boho',
  type: 'bungalow',
  zone: 'isla-mujeres',
  location: 'Playa Norte, Isla Mujeres',
  lat: 21.244,
  lng: -86.735,
  pricePerNight: 185,
  cleaningFee: 45,
  rating: 4.92,
  reviewCount: 76,
  guests: 4,
  bedrooms: 2,
  beds: 2,
  baths: 1,
  images: [IMG.isla, IMG.interior, IMG.pool],
  amenities: ['wifi', 'beachfront', 'ac', 'kitchen', 'ocean-view', 'tv', 'pets'],
  featured: true,
  active: true,
  descES:
  'Encantador bungalow de estilo bohemio a pasos de Playa Norte, la mejor playa de Isla Mujeres. Terraza con hamaca y vista al atardecer sobre el mar turquesa.',
  descEN:
  'Charming boho-style bungalow steps from Playa Norte, the best beach on Isla Mujeres. Terrace with a hammock and sunset views over the turquoise sea.',
  descFR:
  "Charmant bungalow de style bohème à quelques pas de Playa Norte, la plus belle plage d'Isla Mujeres. Terrasse avec hamac et vue sur le coucher de soleil.",
  rulesES: ['Check-in después de las 15:00', 'Check-out antes de las 10:00', 'Ideal para parejas'],
  rulesEN: ['Check-in after 3:00 PM', 'Check-out before 10:00 AM', 'Ideal for couples'],
  rulesFR: ['Arrivée après 15h00', 'Départ avant 10h00', 'Idéal pour les couples'],
  reviews: sampleReviews('p3'),
  bookedDates: futureDates(2, 3),
  blockedDates: futureDates(15, 1)
},
{
  id: 'p4',
  slug: 'penthouse-caribe',
  name: 'Penthouse Vista Caribe',
  type: 'condo',
  zone: 'cancun',
  location: 'Zona Hotelera, Cancún',
  lat: 21.135,
  lng: -86.752,
  pricePerNight: 340,
  cleaningFee: 80,
  rating: 4.85,
  reviewCount: 61,
  guests: 5,
  bedrooms: 2,
  beds: 3,
  baths: 2,
  images: [IMG.interior, IMG.beachfront, IMG.pool],
  amenities: ['wifi', 'pool', 'ac', 'kitchen', 'ocean-view', 'tv', 'workspace', 'washer'],
  featured: false,
  active: true,
  descES:
  'Penthouse en la Zona Hotelera con vistas panorámicas al mar Caribe. Alberca en la azotea y a minutos de los mejores restaurantes de Cancún.',
  descEN:
  'Penthouse in the Hotel Zone with panoramic Caribbean sea views. Rooftop pool and minutes from Cancún’s best restaurants.',
  descFR:
  "Penthouse dans la Zona Hotelera avec vue panoramique sur la mer des Caraïbes. Piscine sur le toit et à quelques minutes des meilleurs restaurants de Cancún.",
  rulesES: ['Check-in después de las 15:00', 'Check-out antes de las 12:00', 'No fumar'],
  rulesEN: ['Check-in after 3:00 PM', 'Check-out before 12:00 PM', 'No smoking'],
  rulesFR: ['Arrivée après 15h00', 'Départ avant 12h00', 'Non-fumeur'],
  reviews: sampleReviews('p4'),
  bookedDates: futureDates(6, 2),
  blockedDates: []
},
{
  id: 'p5',
  slug: 'casa-selva',
  name: 'Casa Selva Tulum',
  type: 'house',
  zone: 'tulum',
  location: 'Aldea Zamá, Tulum',
  lat: 20.211,
  lng: -87.464,
  pricePerNight: 295,
  cleaningFee: 70,
  rating: 4.9,
  reviewCount: 83,
  guests: 6,
  bedrooms: 3,
  beds: 4,
  baths: 3,
  images: [IMG.pool, IMG.isla, IMG.interior],
  amenities: ['wifi', 'pool', 'ac', 'kitchen', 'parking', 'bbq', 'workspace', 'tv'],
  featured: true,
  active: true,
  descES:
  'Refugio de diseño rodeado de selva en el corazón de Tulum, con alberca privada y arquitectura sustentable. A minutos de la playa y los cenotes.',
  descEN:
  'Design retreat surrounded by jungle in the heart of Tulum, with a private pool and sustainable architecture. Minutes from the beach and cenotes.',
  descFR:
  "Refuge design entouré de jungle au cœur de Tulum, avec piscine privée et architecture durable. À quelques minutes de la plage et des cenotes.",
  rulesES: ['Check-in después de las 16:00', 'Check-out antes de las 11:00', 'No eventos'],
  rulesEN: ['Check-in after 4:00 PM', 'Check-out before 11:00 AM', 'No events'],
  rulesFR: ['Arrivée après 16h00', 'Départ avant 11h00', 'Pas d\'événements'],
  reviews: sampleReviews('p5'),
  bookedDates: futureDates(8, 3),
  blockedDates: []
},
{
  id: 'p6',
  slug: 'villa-brisa',
  name: 'Villa Brisa del Mar',
  type: 'villa',
  zone: 'isla-mujeres',
  location: 'El Garrafón, Isla Mujeres',
  lat: 21.204,
  lng: -86.717,
  pricePerNight: 380,
  cleaningFee: 85,
  rating: 4.94,
  reviewCount: 52,
  guests: 8,
  bedrooms: 4,
  beds: 4,
  baths: 3,
  images: [IMG.beachfront, IMG.interior, IMG.isla],
  amenities: ['wifi', 'pool', 'beachfront', 'ac', 'kitchen', 'parking', 'ocean-view', 'washer', 'tv', 'bbq'],
  featured: false,
  active: true,
  descES:
  'Villa espaciosa con vista al mar en el tranquilo sur de Isla Mujeres. Perfecta para desconectarte con alberca privada y grandes terrazas.',
  descEN:
  'Spacious sea-view villa on the quiet south side of Isla Mujeres. Perfect for disconnecting, with a private pool and large terraces.',
  descFR:
  "Villa spacieuse avec vue sur mer dans le sud tranquille d'Isla Mujeres. Parfaite pour se déconnecter, avec piscine privée et grandes terrasses.",
  rulesES: ['Check-in después de las 15:00', 'Check-out antes de las 11:00'],
  rulesEN: ['Check-in after 3:00 PM', 'Check-out before 11:00 AM'],
  rulesFR: ['Arrivée après 15h00', 'Départ avant 11h00'],
  reviews: sampleReviews('p6'),
  bookedDates: futureDates(12, 4),
  blockedDates: futureDates(25, 2)
},
{
  id: 'p7',
  slug: 'casa-jade',
  name: 'Casa Jade Familiar',
  type: 'house',
  zone: 'playa-del-carmen',
  location: 'Playacar, Playa del Carmen',
  lat: 20.618,
  lng: -87.086,
  pricePerNight: 230,
  cleaningFee: 55,
  rating: 4.8,
  reviewCount: 47,
  guests: 6,
  bedrooms: 3,
  beds: 3,
  baths: 2,
  images: [IMG.interior, IMG.pool, IMG.beachfront],
  amenities: ['wifi', 'pool', 'ac', 'kitchen', 'parking', 'tv', 'washer', 'pets'],
  featured: false,
  active: false,
  descES:
  'Casa familiar en el exclusivo fraccionamiento Playacar, con seguridad 24/7, alberca y jardín. Cerca de la playa y campo de golf.',
  descEN:
  'Family home in the exclusive Playacar community, with 24/7 security, pool and garden. Close to the beach and golf course.',
  descFR:
  "Maison familiale dans le quartier exclusif de Playacar, avec sécurité 24h/24, piscine et jardin. Proche de la plage et du golf.",
  rulesES: ['Check-in después de las 15:00', 'Check-out antes de las 11:00', 'Mascotas permitidas'],
  rulesEN: ['Check-in after 3:00 PM', 'Check-out before 11:00 AM', 'Pets allowed'],
  rulesFR: ['Arrivée après 15h00', 'Départ avant 11h00', 'Animaux acceptés'],
  reviews: sampleReviews('p7'),
  bookedDates: [],
  blockedDates: futureDates(1, 30)
}];


export function getProperty(id: string): Property | undefined {
  return PROPERTIES.find((p) => p.id === id || p.slug === id);
}
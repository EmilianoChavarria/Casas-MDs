export type PromoType = 'percentage' | 'fixed' | 'freeNights';

export interface Promotion {
  id: string;
  name: string;
  /** null = promoción automática, sin código. */
  code: string | null;
  type: PromoType;
  value: number;
  maxDiscount: number | null;
  minNights: number | null;
  minAmount: number | null;
  /** Ventana en la que el huésped debe RESERVAR. */
  bookingFrom: string;
  bookingTo: string;
  /** Ventana de las fechas de ESTANCIA cubiertas. */
  stayFrom: string;
  stayTo: string;
  globalLimit: number | null;
  perCustomerLimit: number | null;
  combinable: boolean;
  priority: number;
  propertyIds: string[];
  active: boolean;
  uses: number;
}

export const PROMOTIONS: Promotion[] = [
{
  id: 'pr1',
  name: 'Reserva anticipada invierno',
  code: 'INVIERNO26',
  type: 'percentage',
  value: 15,
  maxDiscount: 400,
  minNights: 4,
  minAmount: null,
  bookingFrom: '2026-08-01',
  bookingTo: '2026-10-31',
  stayFrom: '2026-12-01',
  stayTo: '2027-03-31',
  globalLimit: 100,
  perCustomerLimit: 1,
  combinable: false,
  priority: 20,
  propertyIds: [],
  active: true,
  uses: 43
},
{
  id: 'pr2',
  name: 'Estancia larga automática',
  code: null,
  type: 'percentage',
  value: 10,
  maxDiscount: null,
  minNights: 14,
  minAmount: null,
  bookingFrom: '2026-01-01',
  bookingTo: '2026-12-31',
  stayFrom: '2026-01-01',
  stayTo: '2027-12-31',
  globalLimit: null,
  perCustomerLimit: null,
  combinable: true,
  priority: 5,
  propertyIds: [],
  active: true,
  uses: 12
},
{
  id: 'pr3',
  name: 'Última hora Tulum',
  code: 'TULUM7',
  type: 'fixed',
  value: 75,
  maxDiscount: null,
  minNights: 2,
  minAmount: 300,
  bookingFrom: '2026-08-01',
  bookingTo: '2026-09-30',
  stayFrom: '2026-08-05',
  stayTo: '2026-10-15',
  globalLimit: 50,
  perCustomerLimit: 1,
  combinable: false,
  priority: 15,
  propertyIds: ['p3'],
  active: true,
  uses: 50
},
{
  id: 'pr4',
  name: 'Cuarta noche gratis',
  code: 'CUARTAGRATIS',
  type: 'freeNights',
  value: 1,
  maxDiscount: null,
  minNights: 4,
  minAmount: null,
  bookingFrom: '2026-05-01',
  bookingTo: '2026-07-31',
  stayFrom: '2026-05-15',
  stayTo: '2026-08-31',
  globalLimit: 40,
  perCustomerLimit: 1,
  combinable: false,
  priority: 25,
  propertyIds: [],
  active: false,
  uses: 28
}];


export interface Redemption {
  id: string;
  bookingCode: string;
  guestName: string;
  propertyId: string;
  at: string;
  discount: number;
}

export const REDEMPTIONS: Record<string, Redemption[]> = {
  pr1: [
  {
    id: 'r1',
    bookingCode: 'CC-4821',
    guestName: 'Sophie Marchand',
    propertyId: 'p1',
    at: '2026-08-09',
    discount: 320
  },
  {
    id: 'r2',
    bookingCode: 'CC-4790',
    guestName: 'Regina Ávalos',
    propertyId: 'p2',
    at: '2026-08-04',
    discount: 285
  },
  {
    id: 'r3',
    bookingCode: 'CC-4755',
    guestName: 'Michael Brennan',
    propertyId: 'p3',
    at: '2026-07-29',
    discount: 400
  }],

  pr3: [
  {
    id: 'r4',
    bookingCode: 'CC-4740',
    guestName: 'Laura Kim',
    propertyId: 'p3',
    at: '2026-07-22',
    discount: 75
  }],

  pr2: [],
  pr4: []
};

/** Estados que puede devolver la validación de un cupón en el checkout. */
export type PromoState =
'idle' |
'valid' |
'invalid' |
'expired' |
'exhausted' |
'notApplicable' |
'minNights';

/** Códigos de demostración para ver cada estado en la maqueta. */
export const DEMO_CODES: Record<string, {state: PromoState;discount?: number;date?: string;n?: number;}> = {
  INVIERNO26: { state: 'valid', discount: 320 },
  CUARTAGRATIS: { state: 'expired', date: '2026-07-31' },
  TULUM7: { state: 'exhausted' },
  ISLA10: { state: 'notApplicable' },
  LARGA14: { state: 'minNights', n: 14 }
};
export type AdjustType = 'percentage' | 'fixed' | 'absolute';

export interface Season {
  id: string;
  name: string;
  /** MM-DD, la temporada se define por día del año. */
  from: string;
  to: string;
  recurrence: 'yearly' | 'once';
  adjustType: AdjustType;
  /** Admite negativos para temporada baja. */
  value: number;
  minNights: number;
  priority: number;
  color: string;
  /** Vacío = todas las propiedades. */
  propertyIds: string[];
}

/** Colores permitidos para pintar temporadas, dentro de la paleta del sistema. */
export const SEASON_COLORS = [
{ id: 'coral', label: 'Coral', bg: 'bg-coral-500', soft: 'bg-coral-100', text: 'text-coral-700' },
{ id: 'lagoon', label: 'Turquesa', bg: 'bg-lagoon-500', soft: 'bg-lagoon-100', text: 'text-lagoon-700' },
{ id: 'sand', label: 'Arena', bg: 'bg-sand-500', soft: 'bg-sand-200', text: 'text-sand-800' },
{ id: 'warning', label: 'Ámbar', bg: 'bg-warning-500', soft: 'bg-warning-100', text: 'text-warning-800' },
{ id: 'lagoonDark', label: 'Turquesa oscuro', bg: 'bg-lagoon-800', soft: 'bg-lagoon-200', text: 'text-lagoon-900' }];


export function seasonColor(id: string) {
  return SEASON_COLORS.find((c) => c.id === id) ?? SEASON_COLORS[1];
}

export const SEASONS: Season[] = [
{
  id: 's1',
  name: 'Navidad',
  from: '12-18',
  to: '01-06',
  recurrence: 'yearly',
  adjustType: 'percentage',
  value: 65,
  minNights: 5,
  priority: 30,
  color: 'coral',
  propertyIds: []
},
{
  id: 's2',
  name: 'Semana Santa',
  from: '03-28',
  to: '04-12',
  recurrence: 'yearly',
  adjustType: 'percentage',
  value: 45,
  minNights: 4,
  priority: 30,
  color: 'warning',
  propertyIds: []
},
{
  id: 's3',
  name: 'Temporada alta invierno',
  from: '01-07',
  to: '03-27',
  recurrence: 'yearly',
  adjustType: 'percentage',
  value: 25,
  minNights: 3,
  priority: 20,
  color: 'lagoon',
  propertyIds: []
},
{
  id: 's4',
  name: 'Temporada baja lluvias',
  from: '09-01',
  to: '10-31',
  recurrence: 'yearly',
  adjustType: 'percentage',
  value: -20,
  minNights: 2,
  priority: 10,
  color: 'sand',
  propertyIds: []
},
{
  id: 's5',
  name: 'Puente de diciembre',
  from: '12-10',
  to: '12-20',
  recurrence: 'yearly',
  adjustType: 'fixed',
  value: 40,
  minNights: 3,
  // Misma prioridad que Navidad y con traslape del 18 al 20 → conflicto
  priority: 30,
  color: 'lagoonDark',
  propertyIds: []
}];


/** Detecta traslapes con la misma prioridad, que es el caso ambiguo. */
export function findConflicts(seasons: Season[], candidate: Season): Season[] {
  const toDay = (md: string) => {
    const [m, d] = md.split('-').map(Number);
    return m * 100 + d;
  };
  const overlaps = (a: Season, b: Season) => {
    const a1 = toDay(a.from);
    const a2 = toDay(a.to);
    const b1 = toDay(b.from);
    const b2 = toDay(b.to);
    // Rangos que cruzan el fin de año se parten en dos tramos
    const spans = (s1: number, s2: number): [number, number][] =>
    s1 <= s2 ? [[s1, s2]] : [[s1, 1231], [101, s2]];
    return spans(a1, a2).some(([x1, x2]) =>
    spans(b1, b2).some(([y1, y2]) => x1 <= y2 && y1 <= x2)
    );
  };
  return seasons.filter(
    (s) => s.id !== candidate.id && s.priority === candidate.priority && overlaps(s, candidate)
  );
}
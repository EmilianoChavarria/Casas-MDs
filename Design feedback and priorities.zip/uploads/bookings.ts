import { Booking } from './types';
import { addDays, toISODate } from '../lib/format';

const today = new Date();

export const BOOKINGS: Booking[] = [
{
  id: 'b1',
  code: 'QR-4821',
  propertyId: 'p1',
  guestName: 'Emily Carter',
  guestEmail: 'emily.carter@email.com',
  guestCountry: '🇺🇸 USA',
  checkIn: toISODate(addDays(today, 4)),
  checkOut: toISODate(addDays(today, 9)),
  guests: 6,
  total: 2190,
  status: 'confirmed',
  createdAt: toISODate(addDays(today, -12))
},
{
  id: 'b2',
  code: 'QR-4822',
  propertyId: 'p3',
  guestName: 'Antoine Dubois',
  guestEmail: 'antoine.dubois@email.fr',
  guestCountry: '🇫🇷 France',
  checkIn: toISODate(addDays(today, 2)),
  checkOut: toISODate(addDays(today, 5)),
  guests: 2,
  total: 600,
  status: 'confirmed',
  createdAt: toISODate(addDays(today, -8))
},
{
  id: 'b3',
  code: 'QR-4823',
  propertyId: 'p2',
  guestName: 'María González',
  guestEmail: 'maria.g@email.mx',
  guestCountry: '🇲🇽 México',
  checkIn: toISODate(addDays(today, 10)),
  checkOut: toISODate(addDays(today, 14)),
  guests: 5,
  total: 1100,
  status: 'pending',
  createdAt: toISODate(addDays(today, -3))
},
{
  id: 'b4',
  code: 'QR-4818',
  propertyId: 'p5',
  guestName: 'James Wilson',
  guestEmail: 'jwilson@email.com',
  guestCountry: '🇺🇸 USA',
  checkIn: toISODate(addDays(today, 8)),
  checkOut: toISODate(addDays(today, 11)),
  guests: 4,
  total: 955,
  status: 'confirmed',
  createdAt: toISODate(addDays(today, -20))
},
{
  id: 'b5',
  code: 'QR-4805',
  propertyId: 'p6',
  guestName: 'Sophie Martin',
  guestEmail: 'sophie.martin@email.fr',
  guestCountry: '🇫🇷 France',
  checkIn: toISODate(addDays(today, -12)),
  checkOut: toISODate(addDays(today, -7)),
  guests: 7,
  total: 1985,
  status: 'completed',
  createdAt: toISODate(addDays(today, -40))
},
{
  id: 'b6',
  code: 'QR-4799',
  propertyId: 'p4',
  guestName: 'Carlos Ramírez',
  guestEmail: 'carlos.r@email.mx',
  guestCountry: '🇲🇽 México',
  checkIn: toISODate(addDays(today, -30)),
  checkOut: toISODate(addDays(today, -26)),
  guests: 4,
  total: 1440,
  status: 'cancelled',
  createdAt: toISODate(addDays(today, -55))
}];


// The signed-in demo guest's own trips
export const MY_BOOKINGS: Booking[] = [
{
  id: 'mb1',
  code: 'QR-4831',
  propertyId: 'p1',
  guestName: 'Emily Carter',
  guestEmail: 'emily.carter@email.com',
  guestCountry: '🇺🇸 USA',
  checkIn: toISODate(addDays(today, 22)),
  checkOut: toISODate(addDays(today, 27)),
  guests: 6,
  total: 2190,
  status: 'confirmed',
  createdAt: toISODate(addDays(today, -2))
},
{
  id: 'mb2',
  code: 'QR-4790',
  propertyId: 'p3',
  guestName: 'Emily Carter',
  guestEmail: 'emily.carter@email.com',
  guestCountry: '🇺🇸 USA',
  checkIn: toISODate(addDays(today, -45)),
  checkOut: toISODate(addDays(today, -40)),
  guests: 2,
  total: 970,
  status: 'completed',
  createdAt: toISODate(addDays(today, -70))
}];
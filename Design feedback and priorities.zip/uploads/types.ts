import { Lang } from '../i18n/translations';

export type ZoneId = 'playa-del-carmen' | 'isla-mujeres' | 'tulum' | 'cancun';

export interface Zone {
  id: ZoneId;
  name: string;
  image: string;
  count: number;
}

export type PropertyType = 'villa' | 'house' | 'condo' | 'bungalow';

export type AmenityId =
'wifi' |
'pool' |
'beachfront' |
'ac' |
'kitchen' |
'parking' |
'washer' |
'tv' |
'ocean-view' |
'bbq' |
'workspace' |
'pets';

export interface Review {
  id: string;
  author: string;
  country: string;
  avatar: string;
  rating: number;
  date: string;
  textES: string;
  textEN: string;
  textFR: string;
}

export interface Property {
  id: string;
  slug: string;
  name: string;
  type: PropertyType;
  zone: ZoneId;
  location: string;
  lat: number;
  lng: number;
  pricePerNight: number; // USD
  cleaningFee: number;
  rating: number;
  reviewCount: number;
  guests: number;
  bedrooms: number;
  beds: number;
  baths: number;
  images: string[];
  amenities: AmenityId[];
  featured: boolean;
  active: boolean;
  descES: string;
  descEN: string;
  descFR: string;
  rulesES: string[];
  rulesEN: string[];
  rulesFR: string[];
  reviews: Review[];
  // ISO dates that are unavailable (booked or blocked)
  bookedDates: string[];
  blockedDates: string[];
}

export type BookingStatus =
'confirmed' |
'pending' |
'cancelled' |
'completed' |
'expired';

export interface Booking {
  id: string;
  code: string;
  propertyId: string;
  guestName: string;
  guestEmail: string;
  guestCountry: string;
  checkIn: string; // ISO
  checkOut: string; // ISO
  guests: number;
  total: number; // USD
  status: BookingStatus;
  createdAt: string;
}

export function localizedDesc(p: Property, lang: Lang): string {
  return lang === 'en' ? p.descEN : lang === 'fr' ? p.descFR : p.descES;
}
export function localizedRules(p: Property, lang: Lang): string[] {
  return lang === 'en' ? p.rulesEN : lang === 'fr' ? p.rulesFR : p.rulesES;
}
export function localizedReview(r: Review, lang: Lang): string {
  return lang === 'en' ? r.textEN : lang === 'fr' ? r.textFR : r.textES;
}
import {
  WifiIcon,
  WavesIcon,
  UmbrellaIcon,
  SnowflakeIcon,
  UtensilsIcon,
  CarIcon,
  WashingMachineIcon,
  TvIcon,
  EyeIcon,
  FlameIcon,
  LaptopIcon,
  PawPrintIcon,
  LucideIcon } from
'lucide-react';
import { AmenityId } from './types';
import { Lang } from '../i18n/translations';

interface AmenityDef {
  id: AmenityId;
  icon: LucideIcon;
  es: string;
  en: string;
  fr: string;
}

export const AMENITIES: AmenityDef[] = [
{ id: 'wifi', icon: WifiIcon, es: 'Wifi rápido', en: 'Fast wifi', fr: 'Wifi rapide' },
{ id: 'pool', icon: WavesIcon, es: 'Alberca privada', en: 'Private pool', fr: 'Piscine privée' },
{ id: 'beachfront', icon: UmbrellaIcon, es: 'Frente al mar', en: 'Beachfront', fr: 'Bord de mer' },
{ id: 'ac', icon: SnowflakeIcon, es: 'Aire acondicionado', en: 'Air conditioning', fr: 'Climatisation' },
{ id: 'kitchen', icon: UtensilsIcon, es: 'Cocina equipada', en: 'Full kitchen', fr: 'Cuisine équipée' },
{ id: 'parking', icon: CarIcon, es: 'Estacionamiento', en: 'Free parking', fr: 'Parking gratuit' },
{ id: 'washer', icon: WashingMachineIcon, es: 'Lavadora', en: 'Washer', fr: 'Lave-linge' },
{ id: 'tv', icon: TvIcon, es: 'Smart TV', en: 'Smart TV', fr: 'Smart TV' },
{ id: 'ocean-view', icon: EyeIcon, es: 'Vista al mar', en: 'Ocean view', fr: 'Vue sur mer' },
{ id: 'bbq', icon: FlameIcon, es: 'Asador / BBQ', en: 'BBQ grill', fr: 'Barbecue' },
{ id: 'workspace', icon: LaptopIcon, es: 'Zona de trabajo', en: 'Workspace', fr: 'Espace de travail' },
{ id: 'pets', icon: PawPrintIcon, es: 'Mascotas permitidas', en: 'Pets allowed', fr: 'Animaux acceptés' }];


const map = Object.fromEntries(AMENITIES.map((a) => [a.id, a]));

export function amenityLabel(id: AmenityId, lang: Lang): string {
  const a = map[id];
  if (!a) return id;
  return lang === 'en' ? a.en : lang === 'fr' ? a.fr : a.es;
}

export function amenityIcon(id: AmenityId) {
  return map[id]?.icon ?? WifiIcon;
}
export type MessageStatus = 'sending' | 'sent' | 'delivered' | 'read' | 'failed';
export type MessageAuthor = 'guest' | 'host' | 'system';
export type ConversationStatus = 'open' | 'pending' | 'closed';

export interface Attachment {
  kind: 'image' | 'pdf';
  name: string;
  url: string;
  size: string;
}

export interface ChatMessage {
  id: string;
  author: MessageAuthor;
  text: string;
  at: string; // ISO datetime
  status?: MessageStatus;
  attachment?: Attachment;
  /** Clave i18n para los mensajes de sistema. */
  systemKey?: string;
}

export interface Conversation {
  id: string;
  guestName: string;
  guestEmail: string;
  guestAvatar: string;
  country: string;
  status: ConversationStatus;
  assignee: string | null;
  online: boolean;
  unread: number;
  propertyId?: string;
  bookingCode?: string;
  messages: ChatMessage[];
}

export const AGENTS = ['Mariana Solís', 'Diego Cauich'];

const IMG_ATTACH =
'https://images.unsplash.com/photo-1505142468610-359e7d316be0?auto=format&fit=crop&w=600&q=70';

export const CONVERSATIONS: Conversation[] = [
{
  id: 'c1',
  guestName: 'Sophie Marchand',
  guestEmail: 'sophie.marchand@example.fr',
  guestAvatar: 'https://i.pravatar.cc/80?img=45',
  country: 'Francia',
  status: 'open',
  assignee: 'Mariana Solís',
  online: true,
  unread: 2,
  propertyId: 'p1',
  bookingCode: 'CC-4821',
  messages: [
  {
    id: 'm1',
    author: 'guest',
    text: 'Bonjour ! ¿La casa tiene alberca climatizada? Viajamos en diciembre con niños.',
    at: '2026-08-09T16:42:00'
  },
  {
    id: 'm2',
    author: 'host',
    text: 'Hola Sophie, sí. La alberca está climatizada todo el año y hay salvavidas y cerca de seguridad para niños.',
    at: '2026-08-09T16:51:00',
    status: 'read'
  },
  {
    id: 'm3',
    author: 'system',
    text: '',
    systemKey: 'chat.system.bookingConfirmed',
    at: '2026-08-09T17:10:00'
  },
  {
    id: 'm4',
    author: 'system',
    text: '',
    systemKey: 'chat.system.paymentReceived',
    at: '2026-08-09T17:11:00'
  },
  {
    id: 'm5',
    author: 'guest',
    text: 'Perfecto, ya reservamos. ¿Nos pueden recomendar transporte del aeropuerto de Cancún?',
    at: '2026-08-10T09:04:00'
  },
  {
    id: 'm6',
    author: 'guest',
    text: 'Les mando la foto del vuelo por si ayuda con el horario.',
    at: '2026-08-10T09:05:00',
    attachment: {
      kind: 'image',
      name: 'vuelo-cdg-cun.jpg',
      url: IMG_ATTACH,
      size: '412 KB'
    }
  }]

},
{
  id: 'c2',
  guestName: 'Michael Brennan',
  guestEmail: 'm.brennan@example.com',
  guestAvatar: 'https://i.pravatar.cc/80?img=12',
  country: 'Estados Unidos',
  status: 'pending',
  assignee: null,
  online: false,
  unread: 1,
  propertyId: 'p3',
  messages: [
  {
    id: 'm1',
    author: 'guest',
    text: 'Hi! Is the Tulum house available for the last week of March? Semana Santa dates are confusing on the calendar.',
    at: '2026-08-08T21:18:00'
  },
  {
    id: 'm2',
    author: 'host',
    text: 'Hola Michael, esa semana es temporada alta y pide 5 noches mínimo. Déjame revisar el bloque exacto.',
    at: '2026-08-08T21:40:00',
    status: 'delivered'
  },
  {
    id: 'm3',
    author: 'guest',
    text: 'Sounds good, thanks. Also sending the ID scan you asked for.',
    at: '2026-08-09T08:02:00',
    attachment: {
      kind: 'pdf',
      name: 'identificacion-brennan.pdf',
      url: '#',
      size: '1.2 MB'
    }
  }]

},
{
  id: 'c3',
  guestName: 'Regina Ávalos',
  guestEmail: 'regina.avalos@example.mx',
  guestAvatar: 'https://i.pravatar.cc/80?img=32',
  country: 'México',
  status: 'open',
  assignee: 'Diego Cauich',
  online: true,
  unread: 0,
  propertyId: 'p2',
  bookingCode: 'CC-4790',
  messages: [
  {
    id: 'm1',
    author: 'guest',
    text: 'Buenas tardes, llegamos el viernes a las 11 de la noche. ¿Hay problema con el check-in tarde?',
    at: '2026-08-07T14:22:00'
  },
  {
    id: 'm2',
    author: 'host',
    text: 'Ningún problema. La cerradura es de código, se los enviamos dos días antes de su llegada.',
    at: '2026-08-07T14:30:00',
    status: 'read'
  },
  {
    id: 'm3',
    author: 'guest',
    text: '¡Excelente, muchas gracias!',
    at: '2026-08-07T14:33:00'
  }]

},
{
  id: 'c4',
  guestName: 'Thomas Lefèvre',
  guestEmail: 'thomas.lefevre@example.fr',
  guestAvatar: 'https://i.pravatar.cc/80?img=68',
  country: 'Francia',
  status: 'closed',
  assignee: 'Mariana Solís',
  online: false,
  unread: 0,
  propertyId: 'p4',
  bookingCode: 'CC-4655',
  messages: [
  {
    id: 'm1',
    author: 'guest',
    text: 'Merci beaucoup pour le séjour, tout était parfait.',
    at: '2026-07-28T10:12:00'
  },
  {
    id: 'm2',
    author: 'host',
    text: 'Gracias a ustedes, Thomas. Son bienvenidos cuando quieran volver.',
    at: '2026-07-28T10:40:00',
    status: 'read'
  }]

}];


/** Hilo del huésped en el sitio público, con los cinco estados de mensaje visibles. */
export const GUEST_THREAD: ChatMessage[] = [
{
  id: 'g1',
  author: 'host',
  text: '¡Hola! Soy Mariana, del equipo de Casa Caribe. ¿En qué te puedo ayudar?',
  at: '2026-08-10T10:02:00'
},
{
  id: 'g2',
  author: 'guest',
  text: 'Hola, estoy viendo la Villa Turquesa para diciembre. ¿Aceptan mascotas?',
  at: '2026-08-10T10:05:00',
  status: 'read'
},
{
  id: 'g3',
  author: 'host',
  text: 'Sí, aceptamos mascotas pequeñas con un cargo de 350 MXN por estancia.',
  at: '2026-08-10T10:07:00'
},
{
  id: 'g4',
  author: 'system',
  text: '',
  systemKey: 'chat.system.bookingConfirmed',
  at: '2026-08-10T10:20:00'
},
{
  id: 'g5',
  author: 'guest',
  text: 'Perfecto, ya quedó la reserva. Les mando el comprobante.',
  at: '2026-08-10T10:22:00',
  status: 'delivered',
  attachment: {
    kind: 'pdf',
    name: 'comprobante-pago.pdf',
    url: '#',
    size: '208 KB'
  }
},
{
  id: 'g6',
  author: 'guest',
  text: '¿Me confirman la hora de entrada?',
  at: '2026-08-10T10:24:00',
  status: 'sent'
},
{
  id: 'g7',
  author: 'guest',
  text: 'Y si podemos dejar maletas antes.',
  at: '2026-08-10T10:25:00',
  status: 'sending'
},
{
  id: 'g8',
  author: 'guest',
  text: 'Gracias de antemano.',
  at: '2026-08-10T10:25:30',
  status: 'failed'
}];


/** Historial anterior que se carga al hacer scroll hacia arriba. */
export const GUEST_HISTORY: ChatMessage[] = [
{
  id: 'h1',
  author: 'guest',
  text: 'Buenas, ¿siguen operando las casas de Isla Mujeres en temporada de lluvias?',
  at: '2026-07-14T18:40:00',
  status: 'read'
},
{
  id: 'h2',
  author: 'host',
  text: 'Sí, operamos todo el año. Septiembre y octubre son los meses con más lluvia, pero las casas están disponibles.',
  at: '2026-07-14T18:52:00'
}];